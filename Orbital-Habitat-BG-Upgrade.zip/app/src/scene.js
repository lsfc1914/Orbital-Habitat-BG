import './style.css';

import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';

// Offline shell and installability for supported browsers.
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register(`${import.meta.env.BASE_URL}sw.js`).catch(err => console.warn('Офлайн режимът не е активен:', err)));
}

const ASSET_BASE = import.meta.env.BASE_URL;
const DURATION = 90;
const PARAMS = new URLSearchParams(location.search);
const CAPTURE = PARAMS.has('capture') || PARAMS.has('t');
const REDUCED = matchMedia('(prefers-reduced-motion: reduce)').matches;
function mulberry32(seed) {
  return () => {
    seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(408090);
const TAU = Math.PI * 2;

const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.info.autoReset = false;
renderer.toneMappingExposure = 1.0;
document.body.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x000208);

// nebula starfield sky sphere (ortho camera flattens scene.background to one texel, so use real geometry)
new THREE.TextureLoader().load(`${ASSET_BASE}assets/starfield.jpg`, (t) => {
  t.colorSpace = THREE.SRGBColorSpace;
  // ortho rays are parallel: the screen samples only a tiny patch of the sky sphere,
  // so tile the texture to bring star density back to screen scale
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(36, 36);
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(150, 48, 24),
    new THREE.MeshBasicMaterial({ map: t, side: THREE.BackSide, toneMapped: false, depthWrite: false })
  );
  sky.material.color.setRGB(1.0, 1.0, 1.05);
  sky.renderOrder = -1;
  scene.add(sky);
});

// starfield
{
  const n = 1500, pos = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const z = rand() * 2 - 1, a = rand() * TAU, r = Math.sqrt(1 - z * z);
    const v = new THREE.Vector3(r * Math.cos(a), r * Math.sin(a), z).multiplyScalar(70 + rand() * 50);
    pos.set([v.x, v.y, v.z], i * 3);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  scene.add(new THREE.Points(g, new THREE.PointsMaterial({ color: 0xffffff, size: 0.22, sizeAttenuation: true })));
}

let camera = new THREE.PerspectiveCamera(50, innerWidth / innerHeight, 0.1, 300);
camera.position.set(2.6, 5, -11);
camera.lookAt(-0.1, -0.25, 0.6);

let controls, composer, bloomPass;
const named = {};
const floaters = [];
let earthDayMesh, earthNightMesh, earthGlow, rimGlow, sunSpot, sunBeam;
const homeZoom = () => 0.85 * Math.min(1, (innerWidth / innerHeight) / 1.35);
const focusZoom = () => 2.4 * Math.min(1, (innerWidth / innerHeight) / 1.0);
const state = {
  phase: 0.32,          // 0..1, 0.25 = noon, 0.75 = midnight
  cycle: DURATION,      // seconds per orbit
  fast: false,
  paused: CAPTURE,
  dragging: false,
  dragEarth: false,
  night: false,         // 夜航模式
  growOn: true,
  focus: null,
  penSpin: 0,
  earthDriftK: 1,       // 0 during the intro: earth locked dead-center in the porthole
};

function radialTexture(inner, outer) {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const ctx = c.getContext('2d');
  const g = ctx.createRadialGradient(128, 128, 8, 128, 128, 128);
  g.addColorStop(0, inner); g.addColorStop(1, outer);
  ctx.fillStyle = g; ctx.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

const loadbar = document.getElementById('loadbar');
let introTexReady = 0;
new GLTFLoader().load(`${ASSET_BASE}orbital_full.glb`, (gltf) => {
  scene.add(gltf.scene);
  gltf.scene.traverse((o) => {
    if (o.name) named[o.name] = o;
    if (o.isMesh && o.material) o.material.needsUpdate = true;
    if (o.name.startsWith('float_')) floaters.push({
      m: o, p0: o.position.clone(), r0: o.rotation.clone(),
      sp: 1 + Math.floor(rand() * 3), ph: rand() * TAU,
      ax: new THREE.Vector3(rand() - .5, rand() - .5, rand() - .5).normalize(),
      kick: 0,
    });
  });

  // invisible hit proxies for thin interactive strips (hard to click)
  for (const n of ['led_strip', 'led_strip2']) {
    const o = named[n];
    if (!o) continue;
    const box = new THREE.Box3().setFromObject(o);
    const size = box.getSize(new THREE.Vector3());
    const proxy = new THREE.Mesh(
      new THREE.BoxGeometry(Math.max(size.x, 0.25), Math.max(size.y, 0.15), Math.max(size.z, 0.15)),
      new THREE.MeshBasicMaterial({ visible: false })
    );
    proxy.name = n + '_hit';
    box.getCenter(proxy.position);
    scene.add(proxy);
  }

  // use exported Blender camera; pull back a touch so the capsule exterior reads
  if (gltf.cameras && gltf.cameras.length) camera = gltf.cameras[0];
  camera.zoom = homeZoom();
  camera.updateProjectionMatrix();
  window.__T = { THREE, scene, renderer, gltf, named, state, get camera() { return camera; }, get controls() { return controls; } };
  if (camera.isOrthographicCamera) {
    const a = innerWidth / innerHeight, s = camera.top;
    camera.left = -s * a; camera.right = s * a;
    camera.updateProjectionMatrix();
  }

  controls = new OrbitControls(camera, renderer.domElement);
  controls.target.set(-0.1, -0.25, 0.6);
  controls.enableDamping = true;
  controls.minPolarAngle = 0.75;
  controls.maxPolarAngle = 1.35;
  controls.minZoom = 0.2;
  controls.maxZoom = 3;
  // keep the dollhouse illusion: don't let users orbit to angles where wall items leak outside
  const az0 = controls.getAzimuthalAngle();
  controls.minAzimuthAngle = az0 - 0.5;
  controls.maxAzimuthAngle = az0 + 0.5;

  // ---- earth: fresh sphere + day/night + atmosphere glow ----
  // (GLB 'earth' mesh carries bake-unwrap UVs, useless for equirect textures — replace it)
  const texDay = new THREE.TextureLoader().load(`${ASSET_BASE}assets/earth_day_real.jpg`, () => introTexReady++);
  const texNight = new THREE.TextureLoader().load(`${ASSET_BASE}assets/earth_night_real.png`, () => introTexReady++);
  texDay.colorSpace = texNight.colorSpace = THREE.SRGBColorSpace;
  const e = named['earth'];
  if (e) {
    e.visible = false;
    const geo = new THREE.SphereGeometry(0.62, 64, 32);
    // park the earth well outside the station, centered on the camera→porthole sight-line.
    // NOTE: the exported camera is orthographic — apparent size never shrinks with distance,
    // so "far away" must be small in world units, not far in world units.
    const winC = new THREE.Box3().setFromObject(named['porthole_frame'] || e).getCenter(new THREE.Vector3());
    const vDir = new THREE.Vector3();
    camera.getWorldDirection(vDir);
    const earthPos = winC.clone().addScaledVector(vDir, 20);
    earthPos.y += 0.28;   // sit slightly above window center: horizon + black space
    earthDayMesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: texDay, transparent: true }));
    earthDayMesh.name = 'earth_interactive';
    earthDayMesh.position.copy(earthPos);
    earthDayMesh.rotation.y = 0.8;   // Africa/Europe face the porthole
    e.parent.add(earthDayMesh);
    state.earthHome = earthDayMesh.position.clone();
    earthNightMesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({
      map: texNight, transparent: true, opacity: 0, depthWrite: false, toneMapped: false,
    }));
    earthNightMesh.position.copy(earthDayMesh.position);
    earthNightMesh.quaternion.copy(earthDayMesh.quaternion);
    earthNightMesh.scale.setScalar(1.001);
    e.parent.add(earthNightMesh);
    // atmosphere fresnel shell
    earthGlow = new THREE.Mesh(geo, new THREE.ShaderMaterial({
      transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.BackSide,
      uniforms: { c: { value: new THREE.Color(0x3a7bff) }, k: { value: 0.9 } },
      vertexShader: `varying float vF; void main(){ vec3 n = normalize(normalMatrix * normal);
        vec3 v = normalize((modelViewMatrix * vec4(position,1.0)).xyz);
        vF = pow(1.0 - abs(dot(n, -v)), 2.2); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `uniform vec3 c; uniform float k; varying float vF;
        void main(){ gl_FragColor = vec4(c, vF * k); }`,
    }));
    earthGlow.position.copy(earthDayMesh.position);
    earthGlow.scale.setScalar(1.06);
    e.parent.add(earthGlow);
  }

  // ---- sun spot decal (day) ----
  const spotTex = radialTexture('rgba(255,244,214,0.95)', 'rgba(255,244,214,0)');
  sunSpot = new THREE.Mesh(new THREE.CircleGeometry(1.35, 40),
    new THREE.MeshBasicMaterial({ map: spotTex, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }));
  sunSpot.rotation.x = -Math.PI / 2;
  sunSpot.position.set(1.4, -1.13, 1.2);
  scene.add(sunSpot);
  // light beam from window (slanted plane, fake volumetric)
  sunBeam = new THREE.Mesh(new THREE.PlaneGeometry(1.9, 3.4),
    new THREE.MeshBasicMaterial({ map: radialTexture('rgba(255,240,200,0.30)', 'rgba(255,240,200,0)'),
      transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide }));
  sunBeam.position.set(1.5, -0.3, 1.7);
  sunBeam.rotation.set(Math.PI / 3.2, 0, 0.15);
  scene.add(sunBeam);

  // ---- porthole window reveal (jamb liner) ----
  // the original glitch was never "you can see space at an angle" — that's just how
  // windows work. the real bug was the SEAM between the ring and the hull cutout
  // leaking the earth's glow. a flat collar fixes it but any collar wide enough to
  // cover steep angles sticks out onto the wall and reads as a foreign disc.
  // physically correct fix: line the recess with a short barrel from the frame back
  // through the hull, exactly like a real window jamb. hidden at every angle.
  if (named['porthole_frame']) {
    const fr = new THREE.Box3().setFromObject(named['porthole_frame']);
    const fc = fr.getCenter(new THREE.Vector3());
    const fs = fr.getSize(new THREE.Vector3());
    const rOut = Math.min(fs.x, fs.y) * 0.5;
    // hull is a cylinder of radius 2.45 around the x axis; the cutout (and frame)
    // axis is the hull radial through the window centre, tilted off the z axis.
    const axis = new THREE.Vector3(0, fc.y, Math.sqrt(2.45 * 2.45 - fc.y * fc.y)).normalize();
    const jamb = new THREE.Mesh(
      new THREE.CylinderGeometry(rOut * 0.92, rOut * 0.92, 1.0, 48, 1, true),
      // unlit mid-grey: reads as a shadowed metal recess in every phase
      // (baked-wall white was too eye-catching at glancing angles)
      new THREE.MeshBasicMaterial({ color: 0x8f8d88, side: THREE.DoubleSide })
    );
    jamb.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), axis);
    // spans from inside the frame body (never pokes into the room) through the hull
    jamb.position.copy(fc).addScaledVector(axis, 0.45);
    scene.add(jamb);
  }

  // tame the emissive strengths so bloom doesn't blow out
  for (const k of ['lamp_read', 'growlight', 'led_strip', 'led_strip2']) {
    if (named[k] && named[k].material) named[k].material.emissiveIntensity = 1.1;
  }

  composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  bloomPass = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), 0.35, 0.45, 0.9);
  composer.addPass(bloomPass);
  composer.addPass(new OutputPass());

  document.title = 'Орбитален дом · Orbital Habitat';
  if (!CAPTURE) renderLoop();
  // earth textures render black until streamed in — hold the intro until they arrive
  const gate = setInterval(() => {
    if (introTexReady >= 2) { clearInterval(gate); startIntro(); }
  }, 120);
  setTimeout(() => { clearInterval(gate); startIntro(); }, 4000);   // fallback
}, (ev) => {
  if (ev.total && loadbar) loadbar.style.width = Math.round(ev.loaded / ev.total * 100) + '%';
}, (error) => {
  console.error('Unable to load orbital habitat', error);
  const note = document.querySelector('.load-note');
  if (note) note.textContent = 'Не успяхме да заредим 3D модела. Презареди страницата.';
});

// ---------- interaction ----------
const ray = new THREE.Raycaster();
const ptr = new THREE.Vector2();
let downAt = null, downXY = null;

const FOCUSABLE = ['desk', 'laptop_base', 'sleepbag', 'rack_shelf', 'seat_view', 'bike_wheel',
  'photo_board', 'porthole_frame', 'shelf', 'growlight', 'led_strip', 'led_strip2', 'lamp_read'];
const FOCUS_NAME = { desk: 'desk', laptop_base: 'desk', sleepbag: 'sleepbag', rack_shelf: 'rack',
  seat_view: 'seat', bike_wheel: 'bike', photo_board: 'photos', porthole_frame: 'window', shelf: 'shelf' };
const OBJECT_INFO = {
  desk: ['Орбитална работна станция', 'Следи системите и смяната на деня и нощта'], window: ['Илюминатор към Земята', 'Плъзни, за да наблюдаваш земния хоризонт'],
  hydro: ['Хидропонна лаборатория', 'Докосни лампата, за да смениш осветлението'], sleepbag: ['Спален чувал за микрогравитация', 'Фиксиращи ленти стабилизират тялото по време на сън'],
  seat: ['Наблюдателно място', 'Изчакай следващия изгрев в орбита'], bike: ['Велосипед за упражнения', 'Поддържа физическата форма в микрогравитация'],
  rack: ['Стелаж за провизии', 'Често използваните предмети са закрепени'], photos: ['Снимки от Земята', 'Малък спомен за дома'], shelf: ['Мрежа за съхранение', 'В микрогравитация всичко трябва да е закрепено']
};
let toastTimer;
function toast(text) {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = text; el.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 1800);
}
function showObjectLabel(kind) {
  const el = document.getElementById('object-label');
  const info = OBJECT_INFO[kind];
  if (!el || !info) return;
  el.querySelector('span').textContent = info[0]; el.querySelector('small').textContent = info[1];
  el.classList.add('show');
}
function syncViewButtons(view = 'home') {
  document.querySelectorAll('[data-view]').forEach(b => b.classList.toggle('active', b.dataset.view === view));
}
function interactiveAncestor(o) {
  let p = o;
  while (p && p !== scene) {
    if (p.name && (FOCUSABLE.includes(p.name) || p.name.startsWith('float_') || p.name === 'earth_interactive' || p.name.endsWith('_hit'))) return p;
    p = p.parent;
  }
  return null;
}

function pick(ev) {
  ptr.x = (ev.clientX / innerWidth) * 2 - 1;
  ptr.y = -(ev.clientY / innerHeight) * 2 + 1;
  ray.setFromCamera(ptr, camera);
  const hits = ray.intersectObjects(scene.children, true);
  for (const hit of hits) {
    const object = interactiveAncestor(hit.object);
    if (object) return { ...hit, object };
  }
  return null;
}

// tween helper
const tweens = [];
function tween(obj, prop, to, dur = 0.8) {
  tweens.push({ obj, prop, from: obj[prop].clone ? obj[prop].clone() : obj[prop], to, t: 0, dur });
}
function stepTweens(dt) {
  for (let i = tweens.length - 1; i >= 0; i--) {
    const tw = tweens[i]; tw.t += dt / tw.dur;
    const k = tw.t >= 1 ? 1 : (1 - Math.pow(1 - tw.t, 3));
    if (tw.from.clone) tw.obj[tw.prop].lerpVectors(tw.from, tw.to, k);
    else tw.obj[tw.prop] = tw.from + (tw.to - tw.from) * k;
    if (tw.t >= 1) tweens.splice(i, 1);
  }
}

// ---------- intro ----------
// three acts: (1) deep-night push-in on the porthole with the earth locked
// dead-center, (2) pull back to the dollhouse wide while the phase sweeps
// night->morning so sunrise wakes the cabin, (3) hand over controls.
const INTRO = { active: false, hold: 2.2, pull: 3.4, timers: [] };
function killTween(obj, prop) {
  for (let i = tweens.length - 1; i >= 0; i--)
    if (tweens[i].obj === obj && tweens[i].prop === prop) tweens.splice(i, 1);
}
function startIntro() {
  if (INTRO.started) return;
  INTRO.started = true;
  const loadEl = document.getElementById('load');
  if (loadbar) loadbar.style.width = '100%';
  if (loadEl) { loadEl.classList.add('gone'); setTimeout(() => loadEl.remove(), CAPTURE ? 0 : 650); }
  if (CAPTURE || REDUCED) {
    INTRO.active = true;
    INTRO.homePos = camera.position.clone();
    INTRO.homeTarget = new THREE.Vector3(-0.1, -0.25, 0.6);
    endIntro();
    if (PARAMS.has('t')) window.__seek(Number(PARAMS.get('t')) || 0);
    else { applyPhase(state.phase, 1); stepFloaters(state.phase * DURATION, 0); composer.render(); }
    return;
  }
  // open framed tight on the porthole & earth, then pull back to the dollhouse wide.
  // ORTHO camera: rays are parallel, so the earth (parked 20u along vDir from the window)
  // only stays framed if we keep the view direction and PAN laterally instead of re-aiming.
  const homePos = camera.position.clone();
  const homeTarget = new THREE.Vector3(-0.1, -0.25, 0.6);
  const winC = named['porthole_frame']
    ? new THREE.Box3().setFromObject(named['porthole_frame']).getCenter(new THREE.Vector3())
    : homeTarget.clone();
  const vDir = new THREE.Vector3();
  camera.getWorldDirection(vDir);
  const shift = winC.clone().sub(homeTarget);
  shift.addScaledVector(vDir, -shift.dot(vDir));   // strip the along-ray component
  INTRO.homePos = homePos; INTRO.homeTarget = homeTarget;
  // deep-night open: earth night lights face us, pinned dead-center in the window
  state.phase = 0.78;
  state.earthDriftK = 0;
  controls.enabled = false;
  camera.position.copy(homePos.clone().add(shift));
  controls.target.copy(homeTarget.clone().add(shift));
  if (camera.isOrthographicCamera) {
    camera.zoom = 1.9;
    tween(camera, 'zoom', 2.55, INTRO.hold + 0.5);   // slow push-in on the earth
  }
  camera.updateProjectionMatrix();
  INTRO.active = true;
  const card = document.getElementById('card');
  const skip = document.getElementById('skip');
  INTRO.timers.push(setTimeout(() => card && card.classList.add('show'), 900));
  INTRO.timers.push(setTimeout(() => skip && skip.classList.add('show'), 1900));
  INTRO.timers.push(setTimeout(pullBack, INTRO.hold * 1000));
  INTRO.timers.push(setTimeout(endIntro, (INTRO.hold + INTRO.pull) * 1000 + 200));
}
function pullBack() {
  if (!INTRO.active) return;
  killTween(camera, 'zoom');   // take over from the push-in
  tween(camera, 'position', INTRO.homePos, INTRO.pull);
  tween(controls, 'target', INTRO.homeTarget, INTRO.pull);
  tween(camera, 'zoom', homeZoom(), INTRO.pull);
  tween(state, 'phase', 0.32, INTRO.pull);              // sunrise sweeps the cabin
  tween(state, 'earthDriftK', 1, INTRO.pull + 1.2);     // ease drift back, no snap
  const card = document.getElementById('card');
  const skip = document.getElementById('skip');
  if (skip) skip.classList.remove('show');
  if (card) setTimeout(() => card.classList.remove('show'), INTRO.pull * 450);
}
function endIntro() {
  if (!INTRO.active) return;
  INTRO.active = false;
  INTRO.timers.forEach(clearTimeout); INTRO.timers.length = 0;
  tweens.length = 0;
  camera.position.copy(INTRO.homePos);
  controls.target.copy(INTRO.homeTarget);
  camera.zoom = homeZoom(); camera.updateProjectionMatrix();
  state.phase = 0.32;
  state.earthDriftK = 1;
  controls.enabled = true;
  const card = document.getElementById('card');
  const skip = document.getElementById('skip');
  if (skip) skip.classList.remove('show');
  if (card) { card.classList.remove('show'); setTimeout(() => card.remove(), 1200); }
  document.getElementById('bar')?.classList.add('ready');
  document.getElementById('views')?.classList.add('ready');
  document.getElementById('hint')?.classList.add('ready');
  window.__SCENE_READY__ = true;
}
addEventListener('pointerdown', () => { if (INTRO.active) endIntro(); }, true);

function focusOn(o, forcedKind) {
  const box = new THREE.Box3().setFromObject(o);
  const c = box.getCenter(new THREE.Vector3());
  tween(controls, 'target', c, REDUCED ? 0.01 : 0.9);
  tween(camera, 'zoom', camera.isOrthographicCamera ? focusZoom() : camera.zoom, REDUCED ? 0.01 : 0.9);
  state.focus = o.name;
  const kind = forcedKind || (o.name === 'growlight' ? 'hydro' : FOCUS_NAME[o.name]);
  showObjectLabel(kind);
  syncViewButtons(kind === 'desk' || kind === 'window' || kind === 'hydro' ? kind : 'home');
}
function unfocus() {
  tween(controls, 'target', new THREE.Vector3(-0.1, -0.25, 0.6), REDUCED ? 0.01 : 0.9);
  tween(camera, 'zoom', homeZoom(), REDUCED ? 0.01 : 0.9);
  state.focus = null;
  document.getElementById('object-label')?.classList.remove('show');
  syncViewButtons();
}

renderer.domElement.addEventListener('pointerdown', (ev) => {
  downXY = [ev.clientX, ev.clientY];
  const h = pick(ev);
  downAt = h ? h.object : null;
  if (downAt?.name === 'earth_interactive') {
    state.dragging = true; state.dragEarth = true; controls.enabled = false;
    renderer.domElement.setPointerCapture(ev.pointerId);
    renderer.domElement.style.cursor = 'ew-resize';
    toast('Плъзни наляво или надясно, за да разгледаш Земята');
  }
});
renderer.domElement.addEventListener('pointermove', (ev) => {
  if (state.dragging && downXY) {
    state.phase = (state.phase + (ev.movementX || 0) * 0.0012 + 1) % 1;
  }
  // pen dodge
  if (named['float_pen'] && !state.dragging) {
    const h = pick(ev);
    if (h && h.object.name === 'float_pen') {
      const f = floaters.find(f => f.m === named['float_pen']);
      if (f) f.dodge = 1.0;
    }
  }
});
addEventListener('pointerup', (ev) => {
  const moved = downXY ? Math.hypot(ev.clientX - downXY[0], ev.clientY - downXY[1]) : 99;
  state.dragging = false;
  if (state.dragEarth) { state.dragEarth = false; controls.enabled = true; renderer.domElement.style.cursor = ''; }
  if (moved > 6 || !downAt) { downAt = null; return; }
  const o = downAt; downAt = null;
  const n = o.name;
  if (n === 'growlight') {
    state.growOn = !state.growOn;
    named['growlight'].visible = state.growOn;
    return;
  }
  if (n === 'led_strip' || n === 'led_strip2' || n === 'led_strip_hit' || n === 'led_strip2_hit' || n === 'lamp_read') {
    state.night = !state.night;
    for (const k of ['led_strip', 'led_strip2', 'lamp_read']) if (named[k]) named[k].visible = !state.night;
    return;
  }
  if (n.startsWith('float_')) {
    const f = floaters.find(item => item.m === o);
    if (f) f.kick = 1;
    if (n === 'float_pen') state.penSpin = 6;
    toast('Леко побутване — предметът се носи свободно в микрогравитация');
    return;
  }
  if (FOCUSABLE.includes(n)) { state.focus === n ? unfocus() : focusOn(o); return; }
  if (state.focus) unfocus();
});

// ---------- day/night ----------
function applyPhase(t, dt) {
  // t: 0..1; day window centered at 0.25, night at 0.75
  const day = Math.exp(-Math.pow((t - 0.25) / 0.16, 2));       // 1 at noon
  const nightK = Math.exp(-Math.pow((t - 0.75) / 0.22, 2));    // 1 at midnight
  let exposure = 0.85 + day * 0.32 - nightK * 0.12;
  if (state.night) exposure *= 0.42;
  if (CAPTURE || dt >= 1) renderer.toneMappingExposure = exposure;
  else renderer.toneMappingExposure += (exposure - renderer.toneMappingExposure) * Math.min(1, dt * 6);

  if (bloomPass) bloomPass.strength = 0.32 + day * 0.3;
  if (earthNightMesh) earthNightMesh.material.opacity = Math.min(1, nightK * 1.3);
  if (earthDayMesh) earthDayMesh.material.opacity = 1 - Math.min(1, nightK * 1.2) * 0.96;
  if (earthGlow) earthGlow.material.uniforms.k.value = 0.5 + nightK * 0.8;
  if (sunSpot) {
    sunSpot.material.opacity = day * 0.85 * (state.night ? 0.12 : 1);
    sunSpot.position.x = 1.4 + (t - 0.25) * 3.2;   // sweeps across floor
    sunSpot.position.z = 1.2 + Math.sin(t * Math.PI * 2) * 0.3;
  }
  if (sunBeam) sunBeam.material.opacity = day * 0.45 * (state.night ? 0.1 : 1);
  // earth drift across window
  if (earthDayMesh && state.earthHome) {
    const h = state.earthHome;
    earthDayMesh.position.set(h.x + (t - 0.5) * 0.55 * state.earthDriftK, h.y, h.z);
    if (earthNightMesh) { earthNightMesh.position.copy(earthDayMesh.position); earthNightMesh.quaternion.copy(earthDayMesh.quaternion); }
    if (earthGlow) earthGlow.position.copy(earthDayMesh.position);
    earthDayMesh.rotation.y = 0.8 + t * TAU;
    earthNightMesh?.quaternion.copy(earthDayMesh.quaternion);
  }
}

// ---------- floaters ----------
function stepFloaters(time, dt) {
  const orbitTime = time * TAU / DURATION;
  for (const f of floaters) {
    const bob = Math.sin(orbitTime * f.sp + f.ph) * 0.05;
    const drift = Math.cos(orbitTime * f.sp + f.ph) * 0.04;
    f.m.position.set(f.p0.x + drift, f.p0.y + bob, f.p0.z + Math.sin(orbitTime + f.ph) * 0.03);
    f.m.rotation.copy(f.r0);
    f.m.rotateOnAxis(f.ax, orbitTime * f.sp);
    if (f.dodge && f.dodge > 0) {
      f.m.position.y += f.dodge * 0.25;
      f.dodge = Math.max(0, f.dodge - dt * 1.2);
    }
    if (f.kick > 0) {
      f.m.position.y += Math.sin((1 - f.kick) * Math.PI) * 0.18;
      f.m.position.x += Math.sin((1 - f.kick) * Math.PI) * 0.08;
      f.m.rotateZ((1 - f.kick) * 0.8);
      f.kick = Math.max(0, f.kick - dt * 0.45);
    }
  }
  if (state.penSpin > 0 && named['float_pen']) {
    named['float_pen'].rotation.z += dt * 12 * state.penSpin / 6;
    state.penSpin = Math.max(0, state.penSpin - dt);
  }
}

// ---------- mission briefing and screenshot tools ----------
{
  const panel = document.getElementById('mission-panel');
  const open = document.getElementById('mission-open');
  const close = document.getElementById('mission-close');
  const goals = [...document.querySelectorAll('[data-goal]')];
  const fill = document.getElementById('mission-progress-fill');
  const label = document.getElementById('mission-progress-label');
  const STORAGE_KEY = 'orbital-habitat-mission-v1';
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    goals.forEach(goal => { goal.checked = saved[goal.dataset.goal] === true; });
  } catch (error) { console.warn('Не успяхме да възстановим дневника на мисията.', error); }
  const updateProgress = (persist = false) => {
    const count = goals.filter(item => item.checked).length;
    if (fill) fill.style.width = `${count / goals.length * 100}%`;
    if (label) label.textContent = `${count} от ${goals.length} цели изпълнени`;
    if (persist) {
      try {
        const saved = Object.fromEntries(goals.map(goal => [goal.dataset.goal, goal.checked]));
        localStorage.setItem(STORAGE_KEY, JSON.stringify(saved));
      } catch (error) { console.warn('Дневникът не може да бъде запазен на това устройство.', error); }
    }
  };
  updateProgress();
  const setPanel = (visible) => {
    panel?.classList.toggle('open', visible);
    panel?.setAttribute('aria-hidden', String(!visible));
    open?.setAttribute('aria-expanded', String(visible));
  };
  open?.addEventListener('click', () => setPanel(!panel.classList.contains('open')));
  close?.addEventListener('click', () => setPanel(false));
  goals.forEach(goal => goal.addEventListener('change', () => updateProgress(true)));
  document.getElementById('mission-snapshot')?.addEventListener('click', () => {
    try {
      renderer.domElement.toBlob(blob => {
        if (!blob) { toast('Не успяхме да запазим кадъра'); return; }
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `orbital-habitat-${new Date().toISOString().slice(0,19).replaceAll(':','-')}.png`;
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 1500);
        toast('Кадърът от мисията е запазен');
      }, 'image/png');
    } catch (error) { console.error(error); toast('Не успяхме да запазим кадъра'); }
  });
  document.addEventListener('keydown', ev => { if (ev.key === 'Escape') setPanel(false); });
}

// ---------- bottom control bar ----------
{
  const tl = document.getElementById('tl');
  const thumb = document.getElementById('thumb');
  const btnNight = document.getElementById('btn-night');
  const btnFast = document.getElementById('btn-fast');
  const btnPlay = document.getElementById('btn-play');
  const btnReset = document.getElementById('btn-reset');
  let tlDrag = false;

  function phaseFromEvent(ev) {
    const r = tl.getBoundingClientRect();
    return Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
  }
  tl.addEventListener('pointerdown', (ev) => {
    tlDrag = true; state.dragging = true;
    state.phase = phaseFromEvent(ev);
    tl.setPointerCapture(ev.pointerId);
    ev.stopPropagation();
  });
  tl.addEventListener('pointermove', (ev) => {
    if (tlDrag) state.phase = phaseFromEvent(ev);
  });
  tl.addEventListener('pointerup', () => { tlDrag = false; state.dragging = false; });
  tl.addEventListener('pointercancel', () => { tlDrag = false; state.dragging = false; });
  tl.addEventListener('keydown', ev => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(ev.key)) return;
    ev.preventDefault();
    if (ev.key === 'Home') state.phase = 0;
    else if (ev.key === 'End') state.phase = 0.999;
    else state.phase = (state.phase + (ev.key === 'ArrowRight' ? 1 : -1) / DURATION + 1) % 1;
  });

  btnNight.addEventListener('click', () => {
    state.night = !state.night;
    for (const k of ['led_strip', 'led_strip2', 'lamp_read']) if (named[k]) named[k].visible = !state.night;
  });
  btnPlay.addEventListener('click', () => {
    state.paused = !state.paused;
    toast(state.paused ? 'Орбиталното време е на пауза' : 'Орбиталното време продължава');
  });
  btnReset.addEventListener('click', () => { unfocus(); toast('Върна се към общия изглед на станцията'); });
  document.querySelectorAll('[data-view]').forEach(button => button.addEventListener('click', () => {
    const view = button.dataset.view;
    if (view === 'home') { unfocus(); return; }
    const targetName = view === 'hydro' ? 'growlight' : view === 'window' ? 'porthole_frame' : 'desk';
    if (named[targetName]) focusOn(named[targetName], view);
  }));
  btnFast.addEventListener('click', () => {
    state.fast = !state.fast;
    state.cycle = state.fast ? 15 : DURATION;
    toast(state.fast ? 'Ускорение 6× — един цикъл за 15 секунди' : 'Възстановен е 90-секундният цикъл');
  });

  window.__syncBar = () => {
    thumb.style.left = (state.phase * 100) + '%';
    const day = Math.exp(-Math.pow((state.phase - 0.25) / 0.16, 2));
    const nightK = Math.exp(-Math.pow((state.phase - 0.75) / 0.22, 2));
    const seconds = Math.floor(state.phase * DURATION);
    const phaseName = nightK > day ? 'Нощ над Земята' : day > 0.45 ? 'Дневна светлина' : 'Линия на здрача';
    document.getElementById('phase-name').textContent = phaseName;
    document.getElementById('time-label').textContent = `T+ ${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')} / 01:30`;
    document.getElementById('phase-icon').classList.toggle('day', nightK <= day);
    tl.setAttribute('aria-valuenow', String(seconds));
    tl.setAttribute('aria-valuetext', `${phaseName}, ${seconds} секунди`);
    btnNight.classList.toggle('on', state.night); btnNight.setAttribute('aria-pressed', String(state.night));
    btnFast.classList.toggle('on', state.fast); btnFast.setAttribute('aria-pressed', String(state.fast));
    btnPlay.classList.toggle('paused', state.paused);
    btnPlay.setAttribute('aria-label', state.paused ? '继续时间' : '暂停时间');
    btnPlay.title = state.paused ? '继续时间' : '暂停时间';
  };
}

let last = performance.now();
let lastFrameAt = performance.now();
function frame() {
  if (!controls || !composer) return;
  const now = performance.now();
  const dt = Math.min(0.1, (now - last) / 1000); last = now;
  lastFrameAt = now;
  if (!state.paused && !state.dragging && !INTRO.active) state.phase = (state.phase + dt / state.cycle) % 1;
  applyPhase(state.phase, dt);
  stepFloaters(state.phase * DURATION, state.paused ? 0 : dt);
  stepTweens(dt);
  controls.update();
  camera.updateProjectionMatrix();
  renderer.info.reset();
  composer.render();
  if (window.__syncBar) window.__syncBar();
}
function renderLoop() {
  requestAnimationFrame(renderLoop);
  frame();
}
// rAF stalls in background/hidden tabs — keep animating via timer fallback
setInterval(() => { if (performance.now() - lastFrameAt > 200) frame(); }, 100);
window.__seek = (value) => {
  const t = Number(value);
  if (!Number.isFinite(t) || !composer) return;
  state.paused = true;
  state.phase = ((t % DURATION) + DURATION) % DURATION / DURATION;
  state.penSpin = 0;
  for (const f of floaters) { f.kick = 0; f.dodge = 0; }
  tweens.length = 0;
  controls.target.set(-0.1, -0.25, 0.6);
  camera.zoom = homeZoom(); camera.updateProjectionMatrix();
  state.focus = null;
  document.getElementById('object-label')?.classList.remove('show');
  applyPhase(state.phase, 1);
  stepFloaters(state.phase * DURATION, 0);
  controls.update();
  renderer.info.reset();
  composer.render();
  window.__syncBar?.();
};
window.__play = () => { state.paused = false; last = performance.now(); };
window.__sceneMetrics = () => ({
  calls: renderer.info.render.calls, triangles: renderer.info.render.triangles,
  objects: scene.children.length, floaters: floaters.length, phase: state.phase,
  night: state.night, fast: state.fast, paused: state.paused
});

addEventListener('resize', () => {
  const a = innerWidth / innerHeight;
  if (camera.isOrthographicCamera) {
    const s = camera.top;
    camera.left = -s * a; camera.right = s * a;
    camera.zoom = state.focus ? focusZoom() : homeZoom();
  } else {
    camera.aspect = a;
  }
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth, innerHeight);
  if (composer) { composer.setSize(innerWidth, innerHeight); if (CAPTURE) composer.render(); }
});
