# 素材说明

本项目的轨道生活舱造型、GLB 模型、网页端地球与星空贴图改编自用户选择的 `make3d-orbital-habitat-web` 模板源码包。

模板内 `assets_polyhaven/` 的模型与贴图来自 Poly Haven，依据模板随附说明采用 CC0 协议。其余贴图包含程序化生成与 AI 生成内容；原始来源记录保留在模板的 `blender_source/assets/manifest.json` 中。

本次适配保留原始模型与视觉设计，并重建网页控制界面、确定性 90 秒动画时钟、地球拖动、漂浮物轻推、视角导航及键盘操作。
